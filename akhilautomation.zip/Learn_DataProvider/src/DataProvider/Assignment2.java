package DataProvider;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Assignment2 {
	@Test
	public void LeaveAMessage() {
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://techpub-connect-demo.netlify.app/html/contactus.html");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,900)");
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//div[3]/div/form/div[1]/input")).sendKeys("Akhil");
		driver.findElement(By.xpath("//div[3]/div/form/div[2]/input")).sendKeys("8421391491");
		driver.findElement(By.xpath("//div[3]/div/form/div[3]/input")).sendKeys("akhil@gmail.com");
		driver.findElement(By.xpath("//div[3]/div/form/div[4]/input")).sendKeys("Automation");
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0,700)");
		driver.findElement(By.id("commnent")).sendKeys("I am Here");
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//button[@class='theme_btn border_btn active mt-20']")).click();
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
}
	
	@Test
	public void CheckTitle() {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://techpub-connect-demo.netlify.app/html/contactus.html");
		String ExpectedTitle = "TechPubConnect";
		String ActualTitle =driver.getTitle();
		System.out.println("Title Of the Current Page :"+ActualTitle);
		Assert.assertEquals(ExpectedTitle, ActualTitle);

	}
}